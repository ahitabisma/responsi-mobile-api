<?php

namespace App\Models\keuangan;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Catatan_transaksi extends Model
{
    use HasFactory;
    protected $table = 'catatan_transaksi';
}
