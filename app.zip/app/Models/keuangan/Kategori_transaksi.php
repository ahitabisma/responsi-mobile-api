<?php

namespace App\Models\keuangan;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kategori_transaksi extends Model
{
    use HasFactory;
    protected $table = 'kategori_transaksi';
}
