

<?php $__env->startSection('content'); ?>
    <div>
        <h2 class="text-xl font-bold mb-4">Aplikasi Manajemen Buku</h2>

        <ul class="menu menu-lg bg-base-200 rounded-box w-full">
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a><?php echo e($item->digit_puluhan); ?>. <?php echo e($item->nama_tabel); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\BISMA\www\praktikum-mobile\responsi-mobile-api\resources\views/buku.blade.php ENDPATH**/ ?>