<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>API Praktikum Mobile</title>

    <link rel="icon" href="<?php echo e(asset('favicon_praktikum.jpg')); ?>" type="image/x-icon" />
</head>
<body>
    
</body>
</html><?php /**PATH C:\BISMA\www\praktikum-mobile\responsi-mobile-api\resources\views/welcome.blade.php ENDPATH**/ ?>