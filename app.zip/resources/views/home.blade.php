@extends('layout.main')

@section('content')
    @livewire('cari-segment')
@endsection
