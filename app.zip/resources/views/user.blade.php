@extends('layout.main')

@section('content')
    @livewire('list-user')
@endsection
